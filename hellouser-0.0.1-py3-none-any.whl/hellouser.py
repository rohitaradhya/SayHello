def say_hello(name=None):
    if name is None:
        return "Hello, User!"
    else:
        return f"Hello, {name}!"
